export type PartnerMode = 'business' | 'life';

export interface BusinessPartner {
  id: string;
  name: string;
  avatar: string;
  headline: string;
  location: string;
  role: 'Technical Co-Founder' | 'Growth & CMO' | 'Product Lead' | 'AI / ML Engineer' | 'Operations & Finance' | 'Angel / Strategic Partner';
  experienceYears: number;
  stage: 'Idea & Validation' | 'Prototype / MVP' | 'Funded Seed' | 'Scaling & Revenue';
  equityExpected: string;
  commitment: 'Full-Time' | 'Part-Time to Full' | 'Evenings & Weekends';
  skills: string[];
  pastExits?: string;
  verified: boolean;
  bio: string;
  lookingFor: string;
  timezone: string;
  githubUrl?: string;
  linkedinUrl?: string;
  compatibilityScore: number;
  featured?: boolean;
}

export interface LifePartner {
  id: string;
  name: string;
  age: number;
  avatar: string;
  headline: string;
  location: string;
  profession: string;
  relationshipGoal: 'Life Partner / Marriage' | 'Long-Term Partnership' | 'Deep Connection & Growth' | 'Travel & Life Adventure';
  coreValues: string[];
  loveLanguage: 'Words of Affirmation' | 'Quality Time' | 'Acts of Service' | 'Physical Touch' | 'Shared Purpose';
  lifestyle: string[];
  verified: boolean;
  bio: string;
  lookingFor: string;
  interests: string[];
  relocationReady: boolean;
  compatibilityScore: number;
  featured?: boolean;
}

export interface CompatibilityQuestion {
  id: string;
  mode: PartnerMode;
  question: string;
  options: {
    label: string;
    weight: number;
  }[];
}

export interface ConnectMessage {
  recipientId: string;
  recipientName: string;
  senderName: string;
  senderEmail: string;
  message: string;
  mode: PartnerMode;
}
