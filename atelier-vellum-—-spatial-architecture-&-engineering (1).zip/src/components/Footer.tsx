import React from 'react';
import { Briefcase, Heart, ShieldCheck, Github, Linkedin, Twitter } from 'lucide-react';
import { PartnerMode } from '../types';

interface FooterProps {
  mode: PartnerMode;
  onToggleMode: (mode: PartnerMode) => void;
}

export const Footer: React.FC<FooterProps> = ({ mode, onToggleMode }) => {
  const isBusiness = mode === 'business';

  return (
    <footer className="bg-[#070A12] border-t border-white/10 pt-16 pb-12 text-slate-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Brand Info */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2.5">
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                  isBusiness ? 'bg-cyan-500 text-slate-950' : 'bg-rose-500 text-white'
                }`}
              >
                {isBusiness ? <Briefcase className="w-4 h-4" /> : <Heart className="w-4 h-4 fill-current" />}
              </div>
              <span className="font-display font-black text-xl tracking-tight text-white">
                PARTNER<span className={isBusiness ? 'text-cyan-400' : 'text-rose-400'}> HUB</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              The premier platform designed to help builders and high-agency individuals find their ideal counterpart — whether launching a startup or embarking on a shared life journey.
            </p>
            <div className="flex items-center space-x-2 text-[11px] text-emerald-400 font-mono">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Verified Identity Network</span>
            </div>
          </div>

          {/* Column 1: Mode Switcher */}
          <div>
            <h4 className="font-display font-bold text-white text-xs uppercase tracking-wider mb-3">
              Explore Matchmaking
            </h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => onToggleMode('business')}
                  className={`hover:text-white transition-colors cursor-pointer text-left ${
                    isBusiness ? 'text-cyan-400 font-semibold' : ''
                  }`}
                >
                  💼 Business Co-Founders & Tech Allies
                </button>
              </li>
              <li>
                <button
                  onClick={() => onToggleMode('life')}
                  className={`hover:text-white transition-colors cursor-pointer text-left ${
                    !isBusiness ? 'text-rose-400 font-semibold' : ''
                  }`}
                >
                  ❤️ Life Partners & Soulmates
                </button>
              </li>
              <li>
                <a href="#discovery" className="hover:text-white transition-colors">
                  Top Synergy Matches
                </a>
              </li>
            </ul>
          </div>

          {/* Column 2: Founder & Match Resources */}
          <div>
            <h4 className="font-display font-bold text-white text-xs uppercase tracking-wider mb-3">
              Tools & Agreements
            </h4>
            <ul className="space-y-2 text-slate-400">
              <li>• Standard Dynamic Equity Vesting Template</li>
              <li>• 30-Day Co-Founder Trial Agreement</li>
              <li>• Values & Long-Term Vision Alignment Framework</li>
              <li>• Safe Contact & Direct Messaging Protocol</li>
            </ul>
          </div>

          {/* Column 3: Trust & Mission */}
          <div>
            <h4 className="font-display font-bold text-white text-xs uppercase tracking-wider mb-3">
              Zero-Noise Philosophy
            </h4>
            <p className="text-[11px] text-slate-400 leading-relaxed mb-3">
              No cold recruitment recruiters. No superficial photo swiping. Every profile is manually reviewed for genuine intent, track record, and verified contact details.
            </p>
          </div>
        </div>

        {/* Bottom */}
        <div className="pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px]">
          <div className="text-slate-500 font-mono">
            © 2026 Partner Hub Inc. All rights reserved. Connecting high-conviction partners worldwide.
          </div>
          <div className="flex items-center space-x-6 text-slate-400">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Verification Rules</a>
            <a href="#" className="hover:text-white transition-colors">Code of Conduct</a>
          </div>
        </div>
      </div>
    </footer>
  );
};
