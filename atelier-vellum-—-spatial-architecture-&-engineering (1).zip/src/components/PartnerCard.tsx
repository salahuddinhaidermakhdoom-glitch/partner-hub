import React from 'react';
import { ShieldCheck, MapPin, Bookmark, ArrowUpRight, MessageSquare, Clock, Sparkles } from 'lucide-react';
import { BusinessPartner, LifePartner, PartnerMode } from '../types';

interface PartnerCardProps {
  partner: BusinessPartner | LifePartner;
  mode: PartnerMode;
  isSaved: boolean;
  onToggleSave: (id: string) => void;
  onViewProfile: (partner: BusinessPartner | LifePartner) => void;
  onConnect: (partner: BusinessPartner | LifePartner) => void;
}

export const PartnerCard: React.FC<PartnerCardProps> = ({
  partner,
  mode,
  isSaved,
  onToggleSave,
  onViewProfile,
  onConnect
}) => {
  const isBusiness = mode === 'business';
  const bp = isBusiness ? (partner as BusinessPartner) : null;
  const lp = !isBusiness ? (partner as LifePartner) : null;

  return (
    <div
      className={`rounded-2xl bg-[#0F1422] border transition-all duration-300 hover:-translate-y-1 flex flex-col justify-between p-6 shadow-lg ${
        isBusiness
          ? 'border-white/10 hover:border-cyan-500/40 hover:shadow-cyan-500/10'
          : 'border-white/10 hover:border-rose-500/40 hover:shadow-rose-500/10'
      }`}
    >
      <div>
        {/* Top Header: Avatar, Name & Verification, Bookmark */}
        <div className="flex items-start justify-between gap-4 mb-4">
          <div className="flex items-center space-x-3.5">
            <div className="relative">
              <img
                src={partner.avatar}
                alt={partner.name}
                className="w-14 h-14 rounded-xl object-cover border border-white/10"
                loading="lazy"
              />
              {partner.verified && (
                <div
                  className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-[#0F1422] flex items-center justify-center"
                  title="Verified Profile"
                >
                  <ShieldCheck
                    className={`w-4 h-4 ${isBusiness ? 'text-cyan-400' : 'text-rose-400'}`}
                  />
                </div>
              )}
            </div>

            <div>
              <div className="flex items-center space-x-2">
                <h3 className="font-display font-bold text-lg text-white">
                  {partner.name}
                  {lp && <span className="text-slate-400 font-normal text-sm ml-1.5">, {lp.age}</span>}
                </h3>
              </div>
              <div className="flex items-center text-xs text-slate-400 mt-0.5 space-x-1.5">
                <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                <span className="truncate">{partner.location}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-1.5">
            {/* Compatibility Score */}
            <div
              className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold flex items-center space-x-1 ${
                isBusiness
                  ? 'bg-cyan-500/10 text-cyan-300 border border-cyan-500/20'
                  : 'bg-rose-500/10 text-rose-300 border border-rose-500/20'
              }`}
            >
              <Sparkles className="w-3 h-3" />
              <span>{partner.compatibilityScore}% Match</span>
            </div>

            {/* Bookmark button */}
            <button
              onClick={() => onToggleSave(partner.id)}
              className={`p-2 rounded-lg transition-colors cursor-pointer ${
                isSaved
                  ? isBusiness
                    ? 'bg-cyan-500/20 text-cyan-400'
                    : 'bg-rose-500/20 text-rose-400'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
              aria-label={isSaved ? 'Remove from saved' : 'Save profile'}
            >
              <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
            </button>
          </div>
        </div>

        {/* Headline */}
        <p className="text-xs font-semibold text-slate-200 mb-3 line-clamp-1">
          {partner.headline}
        </p>

        {/* Anti-Slop Clean Metadata (No static pill clutter; clean dots) */}
        {bp && (
          <div className="text-[11px] text-slate-400 font-mono mb-4 flex flex-wrap items-center gap-x-2 gap-y-1 pb-3 border-b border-white/5">
            <span className="text-cyan-400 font-semibold">{bp.role}</span>
            <span>·</span>
            <span>{bp.experienceYears}y exp</span>
            <span>·</span>
            <span>{bp.stage}</span>
            <span>·</span>
            <span className="text-slate-300">{bp.equityExpected}</span>
          </div>
        )}

        {lp && (
          <div className="text-[11px] text-slate-400 font-mono mb-4 flex flex-wrap items-center gap-x-2 gap-y-1 pb-3 border-b border-white/5">
            <span className="text-rose-400 font-semibold">{lp.profession}</span>
            <span>·</span>
            <span>{lp.relationshipGoal}</span>
            <span>·</span>
            <span className="text-slate-300">{lp.loveLanguage}</span>
          </div>
        )}

        {/* Bio preview */}
        <p className="text-xs text-slate-300 leading-relaxed line-clamp-3 mb-4">
          {partner.bio}
        </p>

        {/* Looking For snippet */}
        <div className="p-3 rounded-xl bg-black/30 border border-white/5 text-xs text-slate-300 mb-4">
          <span className="font-mono text-[10px] text-slate-500 block uppercase mb-0.5">
            LOOKING FOR:
          </span>
          <span className="line-clamp-2">{partner.lookingFor}</span>
        </div>

        {/* Skills / Values clean tags */}
        <div className="flex flex-wrap gap-1.5 mb-6">
          {isBusiness &&
            bp?.skills.slice(0, 4).map((skill, idx) => (
              <span
                key={idx}
                className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/5 text-slate-300 border border-white/5"
              >
                {skill}
              </span>
            ))}
          {!isBusiness &&
            lp?.coreValues.slice(0, 4).map((val, idx) => (
              <span
                key={idx}
                className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/5 text-slate-300 border border-white/5"
              >
                {val}
              </span>
            ))}
        </div>
      </div>

      {/* Action Footer */}
      <div className="pt-4 border-t border-white/5 flex items-center justify-between gap-3">
        <button
          onClick={() => onViewProfile(partner)}
          className="text-xs font-semibold text-slate-300 hover:text-white transition-colors flex items-center space-x-1 cursor-pointer"
        >
          <span>View Profile</span>
          <ArrowUpRight className="w-3.5 h-3.5" />
        </button>

        <button
          onClick={() => onConnect(partner)}
          className={`px-4 py-2 rounded-xl font-bold text-xs flex items-center space-x-1.5 transition-transform transform hover:scale-105 cursor-pointer shadow-md ${
            isBusiness
              ? 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-cyan-500/20'
              : 'bg-rose-500 hover:bg-rose-400 text-white shadow-rose-500/20'
          }`}
        >
          <MessageSquare className="w-3.5 h-3.5" />
          <span>{isBusiness ? 'Pitch Co-Founder' : 'Send Note'}</span>
        </button>
      </div>
    </div>
  );
};
