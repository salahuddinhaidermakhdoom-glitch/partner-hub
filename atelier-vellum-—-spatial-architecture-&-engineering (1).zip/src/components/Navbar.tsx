import React from 'react';
import { Briefcase, Heart, Bookmark, Plus, Sparkles, ShieldCheck } from 'lucide-react';
import { PartnerMode } from '../types';

interface NavbarProps {
  mode: PartnerMode;
  onToggleMode: (mode: PartnerMode) => void;
  savedCount: number;
  onOpenSaved: () => void;
  onOpenPostProfile: () => void;
  onOpenQuiz: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  mode,
  onToggleMode,
  savedCount,
  onOpenSaved,
  onOpenPostProfile,
  onOpenQuiz
}) => {
  const isBusiness = mode === 'business';

  return (
    <header className="sticky top-0 z-40 bg-[#090D16]/95 backdrop-blur-md border-b border-white/10 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo & Brand */}
          <div className="flex items-center space-x-3">
            <a href="#" className="flex items-center space-x-2.5 group">
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-300 ${
                  isBusiness
                    ? 'bg-gradient-to-tr from-cyan-500 to-blue-600 shadow-lg shadow-cyan-500/20'
                    : 'bg-gradient-to-tr from-rose-500 to-amber-500 shadow-lg shadow-rose-500/20'
                }`}
              >
                {isBusiness ? (
                  <Briefcase className="w-5 h-5 text-white" />
                ) : (
                  <Heart className="w-5 h-5 text-white fill-white/30" />
                )}
              </div>
              <div className="flex flex-col">
                <div className="flex items-center space-x-1.5">
                  <span className="font-display font-extrabold text-lg sm:text-xl tracking-tight text-white">
                    PARTNER<span className={isBusiness ? 'text-cyan-400' : 'text-rose-400'}> HUB</span>
                  </span>
                  <span className="hidden sm:inline-block text-[10px] font-mono uppercase tracking-wider px-1.5 py-0.5 rounded bg-white/10 text-slate-300">
                    MATCHMAKING
                  </span>
                </div>
                <span className="text-[10px] text-slate-400 font-mono hidden sm:block">
                  {isBusiness ? 'Co-Founders & Technical Allies' : 'Life Partners & Deep Connection'}
                </span>
              </div>
            </a>
          </div>

          {/* Central Mode Switcher */}
          <div className="flex items-center p-1 rounded-xl bg-slate-900/90 border border-white/10 shadow-inner">
            <button
              onClick={() => onToggleMode('business')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                isBusiness
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Briefcase className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Business Co-Founders</span>
              <span className="sm:hidden">Business</span>
            </button>

            <button
              onClick={() => onToggleMode('life')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                !isBusiness
                  ? 'bg-rose-500 text-white font-bold shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Heart className="w-3.5 h-3.5 fill-current" />
              <span className="hidden sm:inline">Life Partners</span>
              <span className="sm:hidden">Life</span>
            </button>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            {/* Compatibility Quiz Trigger */}
            <button
              onClick={onOpenQuiz}
              className="hidden md:flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 text-xs font-medium transition-colors cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Synergy Quiz</span>
            </button>

            {/* Saved Bookmarks */}
            <button
              onClick={onOpenSaved}
              className="relative p-2 sm:px-3 sm:py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 text-xs font-medium transition-colors flex items-center space-x-1.5 cursor-pointer"
              title="Saved Candidate Profiles"
            >
              <Bookmark className="w-4 h-4 text-slate-300" />
              <span className="hidden sm:inline">Saved</span>
              {savedCount > 0 && (
                <span
                  className={`px-1.5 py-0.2 rounded-full font-mono text-[10px] font-bold ${
                    isBusiness ? 'bg-cyan-500 text-slate-950' : 'bg-rose-500 text-white'
                  }`}
                >
                  {savedCount}
                </span>
              )}
            </button>

            {/* Post Profile CTA */}
            <button
              onClick={onOpenPostProfile}
              className={`flex items-center space-x-1.5 px-3.5 py-2 rounded-xl font-bold text-xs shadow-md transition-transform transform hover:scale-105 cursor-pointer ${
                isBusiness
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-slate-950'
                  : 'bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-400 hover:to-pink-400 text-white'
              }`}
            >
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
              <span className="hidden sm:inline">
                {isBusiness ? 'Post Co-Founder Listing' : 'Create Dating Profile'}
              </span>
              <span className="sm:hidden">Post</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
