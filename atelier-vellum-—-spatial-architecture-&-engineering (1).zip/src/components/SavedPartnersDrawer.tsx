import React from 'react';
import { X, Bookmark, ArrowUpRight, MessageSquare, Trash2 } from 'lucide-react';
import { BusinessPartner, LifePartner, PartnerMode } from '../types';

interface SavedPartnersDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  savedPartners: (BusinessPartner | LifePartner)[];
  mode: PartnerMode;
  onRemoveSave: (id: string) => void;
  onViewProfile: (partner: BusinessPartner | LifePartner) => void;
  onConnect: (partner: BusinessPartner | LifePartner) => void;
}

export const SavedPartnersDrawer: React.FC<SavedPartnersDrawerProps> = ({
  isOpen,
  onClose,
  savedPartners,
  mode,
  onRemoveSave,
  onViewProfile,
  onConnect
}) => {
  if (!isOpen) return null;

  const isBusiness = mode === 'business';

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-6 sm:pl-10">
        <div className="w-screen max-w-md bg-[#0C101C] border-l border-white/10 shadow-2xl flex flex-col justify-between">
          {/* Header */}
          <div className="p-6 border-b border-white/10 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Bookmark className="w-5 h-5 text-amber-400 fill-amber-400" />
              <h3 className="font-display font-black text-xl text-white">
                Saved Partners
              </h3>
              <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-white/10 text-slate-300">
                {savedPartners.length}
              </span>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* List */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {savedPartners.length === 0 ? (
              <div className="text-center py-20 space-y-3">
                <Bookmark className="w-12 h-12 text-slate-600 mx-auto" />
                <p className="text-xs text-slate-400">
                  No partners bookmarked yet. Click the bookmark icon on any profile card to save them here for easy follow-up.
                </p>
              </div>
            ) : (
              savedPartners.map((partner) => (
                <div
                  key={partner.id}
                  className="p-4 rounded-2xl bg-[#111726] border border-white/5 flex items-start justify-between gap-3"
                >
                  <img
                    src={partner.avatar}
                    alt={partner.name}
                    className="w-12 h-12 rounded-xl object-cover border border-white/10 shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-display font-bold text-sm text-white truncate">
                      {partner.name}
                    </h4>
                    <p className="text-xs text-slate-400 truncate mt-0.5">
                      {partner.headline}
                    </p>
                    <div className="flex items-center space-x-3 mt-3">
                      <button
                        onClick={() => {
                          onClose();
                          onViewProfile(partner);
                        }}
                        className="text-xs font-semibold text-slate-300 hover:text-white flex items-center space-x-1 cursor-pointer"
                      >
                        <span>View</span>
                        <ArrowUpRight className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => {
                          onClose();
                          onConnect(partner);
                        }}
                        className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center space-x-1 cursor-pointer"
                      >
                        <MessageSquare className="w-3 h-3" />
                        <span>Connect</span>
                      </button>
                    </div>
                  </div>

                  <button
                    onClick={() => onRemoveSave(partner.id)}
                    className="text-slate-500 hover:text-red-400 p-1 cursor-pointer"
                    title="Remove"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))
            )}
          </div>

          {/* Footer */}
          <div className="p-6 border-t border-white/10 bg-[#080B12]">
            <button
              onClick={onClose}
              className="w-full py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs cursor-pointer"
            >
              Continue Browsing Feed
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
