import React from 'react';
import { ShieldCheck, Sparkles, MessageSquare, Handshake, Users, Lock } from 'lucide-react';
import { PartnerMode } from '../types';

interface HowItWorksProps {
  mode: PartnerMode;
}

export const HowItWorks: React.FC<HowItWorksProps> = ({ mode }) => {
  const isBusiness = mode === 'business';

  const steps = isBusiness
    ? [
        {
          num: '01',
          icon: ShieldCheck,
          title: 'Vetted Identity & Track Record',
          desc: 'Every co-founder profile is verified with past code repositories, venture exits, enterprise references, and identity checks.'
        },
        {
          num: '02',
          icon: Sparkles,
          title: 'Algorithmic Synergy Scoring',
          desc: 'We match complementary superpowers: Technical architects pair with GTM operators, ensuring balanced equity and aligned commitment.'
        },
        {
          num: '03',
          icon: MessageSquare,
          title: 'High-Signal Pitching',
          desc: 'No ghosting or cold recruiting spam. High-intent outreach with structured pitch memos and mutual NDA options.'
        },
        {
          num: '04',
          icon: Handshake,
          title: 'Trial Project & Vesting Agreement',
          desc: 'Use our standardized 30-day co-founder trial framework and dynamic equity vesting templates before incorporating.'
        }
      ]
    : [
        {
          num: '01',
          icon: ShieldCheck,
          title: 'Authentic Values Verification',
          desc: 'Profiles undergo photo and background verification to protect our community and guarantee sincere intentions.'
        },
        {
          num: '02',
          icon: Sparkles,
          title: 'Deep Values Alignment',
          desc: 'Match on emotional intelligence, life philosophy, core family vision, and shared lifestyle habits rather than superficial photos.'
        },
        {
          num: '03',
          icon: MessageSquare,
          title: 'Thoughtful Introductions',
          desc: 'Contextual conversation starters and mutual icebreakers designed to skip small talk and dive into meaningful dialogue.'
        },
        {
          num: '04',
          icon: Handshake,
          title: 'Real-World Connection',
          desc: 'Facilitating relaxed first encounters over shared passions, community events, and outdoor experiences.'
        }
      ];

  return (
    <section className="py-20 bg-[#0C101C] border-t border-white/5 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div
            className={`inline-flex items-center space-x-2 px-3 py-1 rounded-full text-xs font-mono font-bold mb-3 ${
              isBusiness
                ? 'bg-cyan-500/10 border border-cyan-500/20 text-cyan-400'
                : 'bg-rose-500/10 border border-rose-500/20 text-rose-400'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>THE PARTNER HUB STANDARD</span>
          </div>
          <h2 className="font-display font-black text-3xl sm:text-5xl text-white tracking-tight">
            Built for Serious, Long-Term Partnerships
          </h2>
          <p className="mt-2 text-slate-400 text-sm sm:text-base">
            Whether building a market-defining company or building a loving life together, quality partners require intentional architecture.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((st) => {
            const Icon = st.icon;
            return (
              <div
                key={st.num}
                className="p-6 rounded-2xl bg-[#090D16] border border-white/10 hover:border-white/20 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="font-mono text-xs font-bold text-slate-500">
                      STEP {st.num}
                    </span>
                    <div
                      className={`p-2 rounded-xl ${
                        isBusiness
                          ? 'bg-cyan-500/10 text-cyan-400'
                          : 'bg-rose-500/10 text-rose-400'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                  </div>
                  <h3 className="font-display font-bold text-lg text-white mb-2">
                    {st.title}
                  </h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {st.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
