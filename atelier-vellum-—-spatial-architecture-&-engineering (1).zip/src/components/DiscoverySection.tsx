import React, { useState } from 'react';
import { Filter, SlidersHorizontal, Sparkles, Check, RotateCcw } from 'lucide-react';
import { BusinessPartner, LifePartner, PartnerMode } from '../types';
import { PartnerCard } from './PartnerCard';

interface DiscoverySectionProps {
  mode: PartnerMode;
  partners: (BusinessPartner | LifePartner)[];
  searchQuery: string;
  savedIds: string[];
  onToggleSave: (id: string) => void;
  onViewProfile: (partner: BusinessPartner | LifePartner) => void;
  onConnect: (partner: BusinessPartner | LifePartner) => void;
}

export const DiscoverySection: React.FC<DiscoverySectionProps> = ({
  mode,
  partners,
  searchQuery,
  savedIds,
  onToggleSave,
  onViewProfile,
  onConnect
}) => {
  const isBusiness = mode === 'business';

  // Filters state
  const [roleFilter, setRoleFilter] = useState('All');
  const [stageFilter, setStageFilter] = useState('All');
  const [goalFilter, setGoalFilter] = useState('All');
  const [onlyVerified, setOnlyVerified] = useState(false);
  const [sortBy, setSortBy] = useState<'match' | 'recent'>('match');

  const businessRoles = ['All', 'Technical Co-Founder', 'Growth & CMO', 'Product Lead', 'Operations & Finance'];
  const businessStages = ['All', 'Idea & Validation', 'Prototype / MVP', 'Funded Seed', 'Scaling & Revenue'];
  const lifeGoals = ['All', 'Life Partner / Marriage', 'Long-Term Partnership', 'Deep Connection & Growth'];

  const filteredPartners = partners.filter((p) => {
    // Search query matching
    const search = searchQuery.toLowerCase().trim();
    if (search) {
      const matchName = p.name.toLowerCase().includes(search);
      const matchBio = p.bio.toLowerCase().includes(search);
      const matchHeadline = p.headline.toLowerCase().includes(search);
      const matchLocation = p.location.toLowerCase().includes(search);
      let matchSpecific = false;

      if (isBusiness) {
        const bp = p as BusinessPartner;
        matchSpecific =
          bp.role.toLowerCase().includes(search) ||
          bp.skills.some((s) => s.toLowerCase().includes(search));
      } else {
        const lp = p as LifePartner;
        matchSpecific =
          lp.profession.toLowerCase().includes(search) ||
          lp.coreValues.some((v) => v.toLowerCase().includes(search));
      }

      if (!matchName && !matchBio && !matchHeadline && !matchLocation && !matchSpecific) {
        return false;
      }
    }

    // Role / Goal filter
    if (isBusiness) {
      const bp = p as BusinessPartner;
      if (roleFilter !== 'All' && bp.role !== roleFilter) return false;
      if (stageFilter !== 'All' && bp.stage !== stageFilter) return false;
    } else {
      const lp = p as LifePartner;
      if (goalFilter !== 'All' && lp.relationshipGoal !== goalFilter) return false;
    }

    if (onlyVerified && !p.verified) return false;

    return true;
  });

  // Sort
  filteredPartners.sort((a, b) => {
    if (sortBy === 'match') return b.compatibilityScore - a.compatibilityScore;
    return 0;
  });

  const resetFilters = () => {
    setRoleFilter('All');
    setStageFilter('All');
    setGoalFilter('All');
    setOnlyVerified(false);
  };

  return (
    <section id="discovery" className="py-12 bg-[#090D16] relative min-h-[600px]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Controls Toolbar */}
        <div className="p-4 sm:p-5 rounded-2xl bg-[#0F1422] border border-white/10 shadow-lg mb-8 space-y-4">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            {/* Left: Filter category selectors */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-mono font-bold text-slate-400 uppercase mr-1">
                {isBusiness ? 'ROLE:' : 'GOAL:'}
              </span>
              {isBusiness
                ? businessRoles.map((role) => (
                    <button
                      key={role}
                      onClick={() => setRoleFilter(role)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                        roleFilter === role
                          ? 'bg-cyan-500 text-slate-950 font-bold shadow-md'
                          : 'bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white'
                      }`}
                    >
                      {role}
                    </button>
                  ))
                : lifeGoals.map((goal) => (
                    <button
                      key={goal}
                      onClick={() => setGoalFilter(goal)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                        goalFilter === goal
                          ? 'bg-rose-500 text-white font-bold shadow-md'
                          : 'bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white'
                      }`}
                    >
                      {goal}
                    </button>
                  ))}
            </div>

            {/* Right: Verified toggle & Sort */}
            <div className="flex items-center space-x-3 pt-2 lg:pt-0 border-t lg:border-t-0 border-white/5">
              <button
                onClick={() => setOnlyVerified(!onlyVerified)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                  onlyVerified
                    ? isBusiness
                      ? 'bg-cyan-500/10 border-cyan-500 text-cyan-300'
                      : 'bg-rose-500/10 border-rose-500 text-rose-300'
                    : 'border-white/10 bg-white/5 text-slate-400 hover:text-white'
                }`}
              >
                ✓ Verified Only
              </button>

              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as 'match' | 'recent')}
                className="bg-black/40 border border-white/10 text-xs text-slate-300 rounded-lg px-2.5 py-1.5 focus:outline-none"
              >
                <option value="match">Highest Synergy Match</option>
                <option value="recent">Recently Active</option>
              </select>
            </div>
          </div>

          {/* Secondary stage filter for business */}
          {isBusiness && (
            <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-white/5 text-xs">
              <span className="font-mono text-slate-400 mr-1">VENTURE STAGE:</span>
              {businessStages.map((stage) => (
                <button
                  key={stage}
                  onClick={() => setStageFilter(stage)}
                  className={`px-2.5 py-1 rounded text-xs transition-colors cursor-pointer ${
                    stageFilter === stage
                      ? 'bg-white/20 text-white font-semibold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {stage}
                </button>
              ))}

              {(roleFilter !== 'All' || stageFilter !== 'All' || onlyVerified) && (
                <button
                  onClick={resetFilters}
                  className="ml-auto text-xs text-slate-400 hover:text-white flex items-center space-x-1 cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset Filters</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* Discovery Feed Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-baseline space-x-2">
            <h2 className="font-display font-black text-xl sm:text-2xl text-white">
              {isBusiness ? 'Available Co-Founders & Technical Allies' : 'Available Life Partners & Soulmates'}
            </h2>
            <span className="text-xs font-mono text-slate-400">
              ({filteredPartners.length} {filteredPartners.length === 1 ? 'profile' : 'profiles'})
            </span>
          </div>
        </div>

        {/* Profiles Grid */}
        {filteredPartners.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPartners.map((partner) => (
              <PartnerCard
                key={partner.id}
                partner={partner}
                mode={mode}
                isSaved={savedIds.includes(partner.id)}
                onToggleSave={onToggleSave}
                onViewProfile={onViewProfile}
                onConnect={onConnect}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-20 rounded-2xl bg-[#0F1422] border border-white/5 p-8">
            <Sparkles className="w-10 h-10 text-slate-500 mx-auto mb-3" />
            <h3 className="font-display font-bold text-lg text-white">No exact partner matches</h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1 mb-4">
              Try broadening your filter criteria or search keyword to discover more candidates.
            </p>
            <button
              onClick={resetFilters}
              className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>
    </section>
  );
};
