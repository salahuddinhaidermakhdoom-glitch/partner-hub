import React from 'react';
import { X, ShieldCheck, MapPin, Bookmark, MessageSquare, Clock, Globe, Award, Sparkles, ExternalLink, Heart } from 'lucide-react';
import { BusinessPartner, LifePartner, PartnerMode } from '../types';

interface PartnerProfileDrawerProps {
  partner: BusinessPartner | LifePartner | null;
  mode: PartnerMode;
  isSaved: boolean;
  onClose: () => void;
  onToggleSave: (id: string) => void;
  onConnect: (partner: BusinessPartner | LifePartner) => void;
}

export const PartnerProfileDrawer: React.FC<PartnerProfileDrawerProps> = ({
  partner,
  mode,
  isSaved,
  onClose,
  onToggleSave,
  onConnect
}) => {
  if (!partner) return null;

  const isBusiness = mode === 'business';
  const bp = isBusiness ? (partner as BusinessPartner) : null;
  const lp = !isBusiness ? (partner as LifePartner) : null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-6 sm:pl-10">
        <div className="w-screen max-w-xl bg-[#0C101C] border-l border-white/10 shadow-2xl flex flex-col justify-between overflow-y-auto">
          {/* Header */}
          <div className="p-6 border-b border-white/10 flex items-center justify-between sticky top-0 bg-[#0C101C]/95 backdrop-blur-md z-10">
            <div className="flex items-center space-x-2">
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                {isBusiness ? 'CO-FOUNDER DOSSIER' : 'PARTNER PROFILE'}
              </span>
              <span className="text-slate-600">/</span>
              <span
                className={`font-mono text-xs font-bold ${
                  isBusiness ? 'text-cyan-400' : 'text-rose-400'
                }`}
              >
                {partner.compatibilityScore}% Compatibility
              </span>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={() => onToggleSave(partner.id)}
                className={`p-2 rounded-xl transition-colors cursor-pointer ${
                  isSaved
                    ? isBusiness
                      ? 'bg-cyan-500/20 text-cyan-400'
                      : 'bg-rose-500/20 text-rose-400'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
                title={isSaved ? 'Saved' : 'Save profile'}
              >
                <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
              </button>

              <button
                onClick={onClose}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Profile Content */}
          <div className="p-6 sm:p-8 space-y-6 flex-1">
            {/* Hero info */}
            <div className="flex items-start space-x-4">
              <div className="relative shrink-0">
                <img
                  src={partner.avatar}
                  alt={partner.name}
                  className="w-20 h-20 rounded-2xl object-cover border-2 border-white/15"
                />
                {partner.verified && (
                  <div className="absolute -bottom-1.5 -right-1.5 p-1 rounded-full bg-[#0C101C] text-emerald-400">
                    <ShieldCheck className="w-4 h-4 fill-emerald-500/20" />
                  </div>
                )}
              </div>

              <div>
                <h3 className="font-display font-black text-2xl text-white">
                  {partner.name}
                  {lp && <span className="text-slate-400 font-normal text-lg ml-2">({lp.age})</span>}
                </h3>
                <p className="text-xs font-semibold text-slate-200 mt-1 leading-snug">
                  {partner.headline}
                </p>
                <div className="flex items-center space-x-2 text-xs text-slate-400 mt-1.5 font-mono">
                  <MapPin className="w-3.5 h-3.5 text-slate-500" />
                  <span>{partner.location}</span>
                </div>
              </div>
            </div>

            {/* Quick Metrics Bar */}
            {bp && (
              <div className="grid grid-cols-3 gap-2.5 p-3 rounded-xl bg-white/[0.02] border border-white/5 text-center font-mono text-xs">
                <div>
                  <span className="text-slate-500 block text-[10px]">STAGE</span>
                  <span className="text-white font-bold">{bp.stage}</span>
                </div>
                <div className="border-x border-white/5">
                  <span className="text-slate-500 block text-[10px]">EQUITY</span>
                  <span className="text-cyan-400 font-bold">{bp.equityExpected}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">COMMITMENT</span>
                  <span className="text-white font-bold">{bp.commitment}</span>
                </div>
              </div>
            )}

            {lp && (
              <div className="grid grid-cols-3 gap-2.5 p-3 rounded-xl bg-white/[0.02] border border-white/5 text-center font-mono text-xs">
                <div>
                  <span className="text-slate-500 block text-[10px]">INTENT</span>
                  <span className="text-white font-bold">{lp.relationshipGoal}</span>
                </div>
                <div className="border-x border-white/5">
                  <span className="text-slate-500 block text-[10px]">LOVE LANGUAGE</span>
                  <span className="text-rose-400 font-bold">{lp.loveLanguage}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">RELOCATION</span>
                  <span className="text-white font-bold">{lp.relocationReady ? 'Open' : 'Local Only'}</span>
                </div>
              </div>
            )}

            {/* Deep Bio */}
            <div>
              <h4 className="text-xs font-mono uppercase text-slate-400 font-bold tracking-wider mb-2">
                {isBusiness ? 'BACKGROUND & TRACK RECORD' : 'LIFE PHILOSOPHY & ABOUT ME'}
              </h4>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed bg-[#111726] p-4 rounded-xl border border-white/5">
                {partner.bio}
              </p>
            </div>

            {/* What They Are Looking For */}
            <div>
              <h4 className="text-xs font-mono uppercase text-slate-400 font-bold tracking-wider mb-2">
                WHAT I’M SEEKING IN A PARTNER
              </h4>
              <p className="text-xs sm:text-sm text-slate-200 leading-relaxed bg-black/40 p-4 rounded-xl border border-white/5">
                {partner.lookingFor}
              </p>
            </div>

            {/* Skills or Values */}
            <div>
              <h4 className="text-xs font-mono uppercase text-slate-400 font-bold tracking-wider mb-2.5">
                {isBusiness ? 'TECHNICAL & DOMAIN SKILLS' : 'CORE VALUES & PRINCIPLES'}
              </h4>
              <div className="flex flex-wrap gap-2">
                {isBusiness &&
                  bp?.skills.map((skill, idx) => (
                    <span
                      key={idx}
                      className="px-3 py-1 rounded-lg bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 text-xs font-mono font-medium"
                    >
                      {skill}
                    </span>
                  ))}
                {!isBusiness &&
                  lp?.coreValues.map((val, idx) => (
                    <span
                      key={idx}
                      className="px-3 py-1 rounded-lg bg-rose-500/10 text-rose-300 border border-rose-500/20 text-xs font-mono font-medium"
                    >
                      {val}
                    </span>
                  ))}
              </div>
            </div>

            {/* Interests or Past Exits */}
            {bp?.pastExits && (
              <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-300 flex items-center space-x-2">
                <Award className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>Verified Exit / Proof: {bp.pastExits}</span>
              </div>
            )}

            {lp?.interests && (
              <div>
                <h4 className="text-xs font-mono uppercase text-slate-400 font-bold tracking-wider mb-2">
                  PASSIONS & WEEKEND INTERESTS
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {lp.interests.map((interest, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 rounded-lg bg-white/5 text-slate-300 text-xs border border-white/5"
                    >
                      {interest}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Sticky Bottom Actions */}
          <div className="p-6 border-t border-white/10 bg-[#090D16] sticky bottom-0">
            <button
              onClick={() => {
                onClose();
                onConnect(partner);
              }}
              className={`w-full py-4 rounded-xl font-bold text-sm tracking-wide shadow-xl flex items-center justify-center space-x-2 cursor-pointer transition-transform transform hover:scale-[1.02] ${
                isBusiness
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-slate-950 shadow-cyan-500/20'
                  : 'bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-400 hover:to-pink-400 text-white shadow-rose-500/20'
              }`}
            >
              <MessageSquare className="w-4 h-4" />
              <span>{isBusiness ? `Send Co-Founder Pitch to ${partner.name}` : `Introduce Yourself to ${partner.name}`}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
