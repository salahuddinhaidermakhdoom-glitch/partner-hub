import React, { useState } from 'react';
import { X, Plus, Sparkles, CheckCircle2 } from 'lucide-react';
import { BusinessPartner, LifePartner, PartnerMode } from '../types';

interface PostProfileModalProps {
  mode: PartnerMode;
  isOpen: boolean;
  onClose: () => void;
  onAddPartner: (newPartner: BusinessPartner | LifePartner) => void;
}

export const PostProfileModal: React.FC<PostProfileModalProps> = ({
  mode,
  isOpen,
  onClose,
  onAddPartner
}) => {
  const isBusiness = mode === 'business';

  const [name, setName] = useState('');
  const [headline, setHeadline] = useState('');
  const [location, setLocation] = useState('');
  const [roleOrGoal, setRoleOrGoal] = useState(
    isBusiness ? 'Technical Co-Founder' : 'Life Partner / Marriage'
  );
  const [bio, setBio] = useState('');
  const [lookingFor, setLookingFor] = useState('');
  const [skillsOrValues, setSkillsOrValues] = useState('');
  const [equityOrLoveLanguage, setEquityOrLoveLanguage] = useState(
    isBusiness ? '30% – 50% Equal Split' : 'Quality Time'
  );

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !headline || !bio || !lookingFor) return;

    const parsedTags = skillsOrValues
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    if (isBusiness) {
      const newBP: BusinessPartner = {
        id: `custom-bp-${Date.now()}`,
        name,
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
        headline,
        location: location || 'Remote / Global',
        role: roleOrGoal as any,
        experienceYears: 5,
        stage: 'Prototype / MVP',
        equityExpected: equityOrLoveLanguage,
        commitment: 'Full-Time',
        skills: parsedTags.length > 0 ? parsedTags : ['TypeScript', 'Growth', 'Product Strategy'],
        verified: true,
        bio,
        lookingFor,
        timezone: 'Local',
        compatibilityScore: 95
      };
      onAddPartner(newBP);
    } else {
      const newLP: LifePartner = {
        id: `custom-lp-${Date.now()}`,
        name,
        age: 30,
        avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=400&q=80',
        headline,
        location: location || 'San Francisco, CA',
        profession: headline.split('·')[0]?.trim() || 'Creative Professional',
        relationshipGoal: roleOrGoal as any,
        coreValues: parsedTags.length > 0 ? parsedTags : ['Intentional Living', 'Empathy', 'Adventure'],
        loveLanguage: equityOrLoveLanguage as any,
        lifestyle: ['Active', 'Lifelong Learner'],
        verified: true,
        bio,
        lookingFor,
        interests: ['Coffee', 'Books', 'Music'],
        relocationReady: true,
        compatibilityScore: 96
      };
      onAddPartner(newLP);
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div className="bg-[#0F1422] border border-white/15 rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-2 rounded-xl hover:bg-white/5 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="mb-5">
          <span className="text-[10px] font-mono uppercase text-amber-400 font-bold block mb-1">
            {isBusiness ? 'FOUNDER RECRUITMENT' : 'INTENTIONAL DATING'}
          </span>
          <h3 className="font-display font-black text-2xl text-white">
            {isBusiness ? 'Post Your Co-Founder Listing' : 'Create Your Partner Profile'}
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            {isBusiness
              ? 'Tell prospective co-founders about your technical or commercial superpower and venture vision.'
              : 'Share your life philosophy, core values, and what intentional partnership means to you.'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 font-bold mb-1">Your Full Name</label>
            <input
              type="text"
              required
              placeholder="e.g. Marcus Vance"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-[#080B12] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-cyan-400"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-bold mb-1">
              {isBusiness ? 'Professional Headline' : 'Personal Headline / Profession'}
            </label>
            <input
              type="text"
              required
              placeholder={
                isBusiness
                  ? 'e.g. Senior Backend Architect · Ex-Google · Seeking GTM Co-Founder'
                  : 'e.g. Sustainable Architect · Weekend Hiker · Voracious Reader'
              }
              value={headline}
              onChange={(e) => setHeadline(e.target.value)}
              className="w-full bg-[#080B12] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-cyan-400"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-bold mb-1">Location</label>
              <input
                type="text"
                required
                placeholder="e.g. New York / Remote"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full bg-[#080B12] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-cyan-400"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-bold mb-1">
                {isBusiness ? 'Your Co-Founder Role' : 'Relationship Goal'}
              </label>
              {isBusiness ? (
                <select
                  value={roleOrGoal}
                  onChange={(e) => setRoleOrGoal(e.target.value)}
                  className="w-full bg-[#080B12] border border-white/10 rounded-xl px-2.5 py-2.5 text-white focus:outline-none"
                >
                  <option value="Technical Co-Founder">Technical Co-Founder</option>
                  <option value="Growth & CMO">Growth & CMO</option>
                  <option value="Product Lead">Product Lead</option>
                  <option value="Operations & Finance">Operations & Finance</option>
                </select>
              ) : (
                <select
                  value={roleOrGoal}
                  onChange={(e) => setRoleOrGoal(e.target.value)}
                  className="w-full bg-[#080B12] border border-white/10 rounded-xl px-2.5 py-2.5 text-white focus:outline-none"
                >
                  <option value="Life Partner / Marriage">Life Partner / Marriage</option>
                  <option value="Long-Term Partnership">Long-Term Partnership</option>
                  <option value="Deep Connection & Growth">Deep Connection & Growth</option>
                </select>
              )}
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-bold mb-1">
              {isBusiness ? 'Bio & Venture Background' : 'Bio & What Makes You Tick'}
            </label>
            <textarea
              required
              rows={3}
              placeholder="Tell your story authentically..."
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              className="w-full bg-[#080B12] border border-white/10 rounded-xl p-3 text-white focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-bold mb-1">
              What Specific Partner Qualities Are You Seeking?
            </label>
            <textarea
              required
              rows={2}
              placeholder="Be direct about the skills, mindset, or values you need..."
              value={lookingFor}
              onChange={(e) => setLookingFor(e.target.value)}
              className="w-full bg-[#080B12] border border-white/10 rounded-xl p-3 text-white focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-bold mb-1">
              {isBusiness ? 'Key Skills (Comma separated)' : 'Core Values (Comma separated)'}
            </label>
            <input
              type="text"
              placeholder={isBusiness ? 'PyTorch, Rust, Enterprise Sales, LLMs' : 'Empathy, Growth, Outdoors, Curiosity'}
              value={skillsOrValues}
              onChange={(e) => setSkillsOrValues(e.target.value)}
              className="w-full bg-[#080B12] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none"
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className={`w-full py-3.5 rounded-xl font-bold text-xs tracking-wide shadow-lg cursor-pointer ${
                isBusiness
                  ? 'bg-cyan-500 hover:bg-cyan-400 text-slate-950'
                  : 'bg-rose-500 hover:bg-rose-400 text-white'
              }`}
            >
              Publish Profile to Partner Hub
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
