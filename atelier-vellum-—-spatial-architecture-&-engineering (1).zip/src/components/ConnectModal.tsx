import React, { useState } from 'react';
import { X, Send, CheckCircle2, MessageSquare, Sparkles } from 'lucide-react';
import { BusinessPartner, LifePartner, PartnerMode } from '../types';

interface ConnectModalProps {
  partner: BusinessPartner | LifePartner | null;
  mode: PartnerMode;
  onClose: () => void;
  onSuccess: (message: string) => void;
}

export const ConnectModal: React.FC<ConnectModalProps> = ({
  partner,
  mode,
  onClose,
  onSuccess
}) => {
  const [senderName, setSenderName] = useState('');
  const [senderContact, setSenderContact] = useState('');
  const [message, setMessage] = useState('');
  const [isSent, setIsSent] = useState(false);

  if (!partner) return null;

  const isBusiness = mode === 'business';

  const defaultTemplates = isBusiness
    ? [
        "Hey! Your engineering track record is exceptional. I'm a B2B growth operator with 4 enterprise LOIs ready to build an MVP. Let's do a 20-min chemistry call.",
        "Hi there, saw your listing. I have deep domain expertise in fintech and venture funding. Would love to review mutual synergies.",
        "Your vision for software craft aligns with mine. Are you open to a coffee chat this Thursday?"
      ]
    : [
        "Hi! Your bio about intentional living, deep conversations, and weekend hikes really resonated with me. I'd love to get to know you.",
        "Hello! I also cherish creativity and emotional authenticity in partnership. Would you like to connect for a casual conversation?",
        "Loved reading about your passion for community and quiet joy. Wishing you a wonderful week!"
      ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!senderName || !senderContact || !message) return;

    setIsSent(true);
    setTimeout(() => {
      onSuccess(`Your introduction to ${partner.name} has been delivered! They will review your profile and respond within 24 hours.`);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="bg-[#0F1422] border border-white/15 rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-2 rounded-xl hover:bg-white/5 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {!isSent ? (
          <div>
            <div className="flex items-center space-x-3 mb-5">
              <img
                src={partner.avatar}
                alt={partner.name}
                className="w-12 h-12 rounded-xl object-cover border border-white/10"
              />
              <div>
                <h3 className="font-display font-black text-lg text-white">
                  Connect with {partner.name}
                </h3>
                <span className="text-xs text-slate-400 font-mono">
                  {isBusiness ? 'Verified Co-Founder Inquiry' : 'Personal Introduction'}
                </span>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-mono uppercase text-slate-300 mb-1">
                  Your Full Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Elena Rostova"
                  value={senderName}
                  onChange={(e) => setSenderName(e.target.value)}
                  className="w-full bg-[#080B12] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="block text-xs font-mono uppercase text-slate-300 mb-1">
                  Your Email / LinkedIn / Phone
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. linkedin.com/in/yourname or email@domain.com"
                  value={senderContact}
                  onChange={(e) => setSenderContact(e.target.value)}
                  className="w-full bg-[#080B12] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              {/* Starter template pills */}
              <div>
                <span className="text-[10px] font-mono uppercase text-slate-500 block mb-1.5">
                  OR CLICK A QUICK CONVERSATION STARTER:
                </span>
                <div className="space-y-1.5">
                  {defaultTemplates.map((t, idx) => (
                    <button
                      type="button"
                      key={idx}
                      onClick={() => setMessage(t)}
                      className="text-left w-full p-2 rounded-lg bg-white/5 hover:bg-white/10 text-[11px] text-slate-300 border border-white/5 transition-colors cursor-pointer line-clamp-1"
                    >
                      "{t}"
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono uppercase text-slate-300 mb-1">
                  Your Personalized Pitch or Note
                </label>
                <textarea
                  required
                  rows={4}
                  placeholder={
                    isBusiness
                      ? 'Share your background, current traction or idea, and what you’re looking to build together...'
                      : 'Share what resonated with you about their life vision and what meaningful connection looks like to you...'
                  }
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full bg-[#080B12] border border-white/10 rounded-xl p-3 text-xs sm:text-sm text-white focus:outline-none focus:border-cyan-400 leading-relaxed"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className={`w-full py-3.5 rounded-xl font-bold text-xs tracking-wide shadow-lg flex items-center justify-center space-x-2 cursor-pointer transition-transform transform hover:scale-[1.02] ${
                    isBusiness
                      ? 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-cyan-500/20'
                      : 'bg-rose-500 hover:bg-rose-400 text-white shadow-rose-500/20'
                  }`}
                >
                  <Send className="w-4 h-4" />
                  <span>Send Message to {partner.name}</span>
                </button>
              </div>
            </form>
          </div>
        ) : (
          <div className="text-center py-8 space-y-3">
            <div className="w-12 h-12 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h4 className="font-display font-bold text-lg text-white">Introduction Dispatched!</h4>
            <p className="text-xs text-slate-400">
              Notification sent to {partner.name}. Expect a response directly in your inbox.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
