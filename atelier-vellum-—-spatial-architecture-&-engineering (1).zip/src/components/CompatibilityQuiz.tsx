import React, { useState } from 'react';
import { X, Sparkles, Check, ArrowRight, RotateCcw } from 'lucide-react';
import { PartnerMode } from '../types';
import { COMPATIBILITY_QUESTIONS } from '../data/partnersData';

interface CompatibilityQuizProps {
  mode: PartnerMode;
  isOpen: boolean;
  onClose: () => void;
  onSelectPartnerRecommendation: (partnerId: string) => void;
}

export const CompatibilityQuiz: React.FC<CompatibilityQuizProps> = ({
  mode,
  isOpen,
  onClose,
  onSelectPartnerRecommendation
}) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [showResults, setShowResults] = useState(false);

  if (!isOpen) return null;

  const questions = COMPATIBILITY_QUESTIONS.filter((q) => q.mode === mode);
  const isBusiness = mode === 'business';

  const handleSelectOption = (weight: number) => {
    const nextAnswers = [...answers, weight];
    setAnswers(nextAnswers);

    if (currentStep + 1 < questions.length) {
      setCurrentStep(currentStep + 1);
    } else {
      setShowResults(true);
    }
  };

  const handleReset = () => {
    setCurrentStep(0);
    setAnswers([]);
    setShowResults(false);
  };

  const currentQ = questions[currentStep];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div className="bg-[#0F1422] border border-white/15 rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-2 rounded-xl hover:bg-white/5 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {!showResults ? (
          <div>
            {/* Header */}
            <div className="mb-6">
              <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-xs font-mono font-bold text-amber-400 mb-2">
                <Sparkles className="w-3.5 h-3.5" />
                <span>60-SECOND {isBusiness ? 'CO-FOUNDER SYNERGY' : 'LIFE VALUES'} TEST</span>
              </div>
              <div className="flex justify-between items-baseline">
                <h3 className="font-display font-black text-xl text-white">
                  Question {currentStep + 1} of {questions.length}
                </h3>
                <span className="text-xs font-mono text-slate-500">
                  Step {currentStep + 1}/{questions.length}
                </span>
              </div>
            </div>

            {/* Question */}
            <div className="space-y-4">
              <h4 className="text-sm sm:text-base font-semibold text-slate-200">
                {currentQ.question}
              </h4>

              <div className="space-y-2.5">
                {currentQ.options.map((opt, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSelectOption(opt.weight)}
                    className="w-full text-left p-3.5 rounded-xl bg-[#080B12] hover:bg-white/5 border border-white/10 hover:border-white/20 transition-all text-xs sm:text-sm text-slate-300 hover:text-white flex items-center justify-between cursor-pointer group"
                  >
                    <span>{opt.label}</span>
                    <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-amber-400 transition-colors" />
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center py-4 space-y-4">
            <div
              className={`w-16 h-16 rounded-full mx-auto flex items-center justify-center font-display font-black text-2xl shadow-xl ${
                isBusiness
                  ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40'
                  : 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
              }`}
            >
              96%
            </div>

            <h3 className="font-display font-black text-2xl text-white">
              High Synergy Profile Unlocked!
            </h3>

            <p className="text-xs sm:text-sm text-slate-300 max-w-sm mx-auto leading-relaxed">
              Based on your responses, you complement high-agency operators who value execution clarity and emotional stability.
            </p>

            <div className="p-4 rounded-xl bg-black/40 border border-white/10 text-left space-y-2">
              <span className="text-[10px] font-mono uppercase text-slate-400 font-bold block">
                TOP RECOMMENDED MATCHES:
              </span>
              <div className="space-y-2 text-xs text-white">
                <button
                  onClick={() => {
                    onClose();
                    onSelectPartnerRecommendation(isBusiness ? 'bp-1' : 'lp-1');
                  }}
                  className="w-full flex items-center justify-between p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
                >
                  <span className="font-bold">
                    {isBusiness ? 'Alexander Vance (AI Systems Architect)' : 'Maya Lin (Sustainable Architect)'}
                  </span>
                  <span className={isBusiness ? 'text-cyan-400' : 'text-rose-400'}>97% Match →</span>
                </button>
                <button
                  onClick={() => {
                    onClose();
                    onSelectPartnerRecommendation(isBusiness ? 'bp-2' : 'lp-2');
                  }}
                  className="w-full flex items-center justify-between p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
                >
                  <span className="font-bold">
                    {isBusiness ? 'Priya Sharma (B2B SaaS Growth Lead)' : 'Julian Thorne (Genetics Researcher)'}
                  </span>
                  <span className={isBusiness ? 'text-cyan-400' : 'text-rose-400'}>94% Match →</span>
                </button>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={handleReset}
                className="flex-1 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 font-bold text-xs flex items-center justify-center space-x-1.5 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Retake Quiz</span>
              </button>
              <button
                onClick={onClose}
                className={`flex-1 py-2.5 rounded-xl font-bold text-xs cursor-pointer shadow-md ${
                  isBusiness
                    ? 'bg-cyan-500 hover:bg-cyan-400 text-slate-950'
                    : 'bg-rose-500 hover:bg-rose-400 text-white'
                }`}
              >
                Browse Recommendations
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
