import React from 'react';
import { Search, Briefcase, Heart, ShieldCheck, Sparkles, ArrowRight, Users, CheckCircle2 } from 'lucide-react';
import { PartnerMode } from '../types';

interface HeroProps {
  mode: PartnerMode;
  onToggleMode: (mode: PartnerMode) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onOpenQuiz: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  mode,
  onToggleMode,
  searchQuery,
  onSearchChange,
  onOpenQuiz
}) => {
  const isBusiness = mode === 'business';

  return (
    <section className="relative pt-12 pb-16 md:pt-20 md:pb-20 overflow-hidden">
      {/* Dynamic ambient background glow */}
      <div
        className={`absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] blur-[140px] pointer-events-none -z-10 rounded-full transition-colors duration-700 ${
          isBusiness ? 'bg-cyan-600/15' : 'bg-rose-600/15'
        }`}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        {/* Mode Selector Segment */}
        <div className="inline-flex items-center p-1.5 rounded-2xl bg-slate-900/90 border border-white/10 shadow-xl mb-6">
          <button
            onClick={() => onToggleMode('business')}
            className={`flex items-center space-x-2 px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
              isBusiness
                ? 'bg-cyan-500 text-slate-950 shadow-md font-extrabold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Briefcase className="w-4 h-4" />
            <span>Business Co-Founders</span>
          </button>
          <button
            onClick={() => onToggleMode('life')}
            className={`flex items-center space-x-2 px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
              !isBusiness
                ? 'bg-rose-500 text-white shadow-md font-extrabold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Heart className="w-4 h-4 fill-current" />
            <span>Life & Soulmate Partners</span>
          </button>
        </div>

        {/* Dynamic Heading & Copy */}
        {isBusiness ? (
          <div className="space-y-4 max-w-4xl mx-auto">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-xs font-mono text-cyan-400">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>100% IDENTITY & TRACK RECORD VERIFIED PROFILES</span>
            </div>
            <h1 className="font-display font-black text-4xl sm:text-6xl tracking-tight text-white leading-[1.08]">
              Find the missing half of your{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-500">
                founding team.
              </span>
            </h1>
            <p className="text-slate-300 text-base sm:text-lg max-w-2xl mx-auto leading-relaxed">
              Connect with vetted technical CTOs, enterprise GTM operators, and product architects ready to commit equity, build high-conviction software, and scale together.
            </p>
          </div>
        ) : (
          <div className="space-y-4 max-w-4xl mx-auto">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-rose-500/10 border border-rose-500/20 text-xs font-mono text-rose-400">
              <Heart className="w-3.5 h-3.5 fill-rose-400" />
              <span>INTENTIONAL RELATIONSHIPS & SHARED VALUES</span>
            </div>
            <h1 className="font-display font-black text-4xl sm:text-6xl tracking-tight text-white leading-[1.08]">
              Find a partner who shares your{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-rose-400 via-pink-300 to-amber-400">
                life vision.
              </span>
            </h1>
            <p className="text-slate-300 text-base sm:text-lg max-w-2xl mx-auto leading-relaxed">
              Skip the shallow swipe games. Connect with self-aware, emotionally mature individuals looking for deep alignment, reciprocal devotion, and lifelong partnership.
            </p>
          </div>
        )}

        {/* Global Instant Search Bar & Filter Shortcuts */}
        <div className="mt-8 max-w-2xl mx-auto">
          <div className="relative flex items-center">
            <Search className="w-5 h-5 text-slate-400 absolute left-4 pointer-events-none" />
            <input
              type="text"
              placeholder={
                isBusiness
                  ? 'Search by role, stack (Rust, PyTorch, React), equity, or city...'
                  : 'Search by values (Family, Adventure, Emotional Depth), city, or habits...'
              }
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full bg-[#111726] border border-white/15 rounded-2xl pl-12 pr-4 py-3.5 text-sm text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-cyan-500/50 shadow-xl transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-4 text-xs font-mono text-slate-400 hover:text-white"
              >
                Clear
              </button>
            )}
          </div>
        </div>

        {/* Trust Badges */}
        <div className="mt-10 flex flex-wrap items-center justify-center gap-6 sm:gap-10 text-xs text-slate-400 font-mono">
          <div className="flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>Zero Anonymous Spam</span>
          </div>
          <div className="flex items-center space-x-2">
            <Users className="w-4 h-4 text-sky-400" />
            <span>{isBusiness ? '4,800+ Active Builders' : '6,200+ Verified Singles'}</span>
          </div>
          <div className="flex items-center space-x-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <button onClick={onOpenQuiz} className="underline hover:text-white cursor-pointer">
              Take 60s Synergy Alignment Quiz
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
